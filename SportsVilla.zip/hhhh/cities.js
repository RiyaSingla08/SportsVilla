// List of cities (Simplified)
var cities = [
    "Mumbai", "Delhi", "Bangalore", "Hyderabad", "Ahmedabad",
    "Chennai", "Kolkata", "Surat", "Pune", "Jaipur",
    // Add more cities as needed
];

// Function to populate the dropdown with cities
function populateDropdown() {
    var citySelect = document.getElementById("citySelect");
    cities.forEach(function(city) {
        var option = document.createElement("option");
        option.text = city;
        option.value = city;
        citySelect.add(option);
    });
}

// Populate the dropdown when the page loads
populateDropdown();

<?php
// Include the database connection file
include "database.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $sports_interest = $_POST['sport'];
    $skill_level = $_POST['level'];
    $availability = $_POST['availability'];
    $comments = $_POST['comment'];

    // Insert data into the 'single' table
    $sql = "INSERT INTO single (fname, lname, email, phone, city, state, country, sport, level, availability, comment)
            VALUES ('$firstname', '$lastname', '$email', '$phone', '$city', '$state', '$country', '$sports_interest', '$skill_level', '$availability', '$comments')";

    if ($conn->query($sql) === TRUE) {
        // Signup successful
        echo "Signup successful. Redirecting...";
        // Redirect the user to a success page
        header("Location: page1.html");
        exit();
    } else {
        // Error in SQL query
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sports Enthusiast Sign Up</title>
  <link rel="stylesheet" href="styleheader.css">
  <style>
body {
 font-family: 'Poppins,Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
 margin: 0;
 padding: 0;
 background-color: #f4f4f4;
 /*background-image: url('sports.jpg');  Specify the path to your image */
 background-size: cover;
 background-position: center;
 background: linear-gradient(to top, #fff1eb 0%, #ace0f9 100%);
}

.container {
 max-width: 400px;
 margin: 50px auto;
 
 padding: 20px;
 background-color: rgba(255, 255, 255, 0.8); /* Add a semi-transparent background color to improve readability */
 border-radius: 10px;
 box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
#skill-level {
      height:50px;
      width: 400px;; /* Adjust the width as needed */
      margin-right: 20px;
    }
.h2{
color:#113f67;
}
.signup-form {
 text-align: center;
}

.signup-form h2 {
 margin-bottom: 30px;
 color: #333;
}

input[type="text"],
input[type="email"],
input[type="tel"],
select,
textarea {
 width: calc(100% - 20px);
 margin-bottom: 20px;
 padding: 12px;
 border: 1px solid #ccc;
 border-radius: 5px;
 font-size: 16px;
}

select {
 height: 120px;
}

label {
 display: block;
 text-align: left;
 margin-bottom: 10px;
 color: #555;
 font-weight: bold;
}

textarea {
 resize: vertical;
}

button {
 width: 100%;
 padding: 12px;
 background-color: #113f67;
 color: #fff;
 border: none;
 border-radius: 5px;
 cursor: pointer;
 font-size: 16px;
 transition: background-color 0.3s ease;
}

button:hover {
 background-color: #0056b3;
}

.terms {
 text-align: left;
 margin-bottom: 20px;
}

.terms label {
 font-size: 14px;
}

.terms a {
 color: #113f67;
 text-decoration: none;
}

.terms a:hover {
 text-decoration: underline;
}
  </style>
</head>
<body>
  <header>
    <div class="logo">
                <img src="LOGO.png" alt="Logo">
            </div>
            <nav>
                <ul>
                    <li><a href="index1.html">Home</a></li>
                    <li><a href="login.html">Login</a></li>
                    <li><a href="individual.html">Sign Up</a></li>
                    <li><a href="contactus.html">Contact Us</a></li>
                </ul>
            </nav>
    </header>
  <div class="container">
  <form class="signup-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <h2>Join Our Sports Community</h2>
      <input type="text" placeholder="First Name" required>
      <input type="text" placeholder="Last Name" required>
      <input type="email" placeholder="Email" required>
      <input type="tel" placeholder="Phone (Optional)">
      <input type="text" placeholder="City" required>
      <input type="text" placeholder="State/Province" required>
      <input type="text" placeholder="Country" required>
	  
      
	  <label for="skill-level">Select Sports of Interest:</label>
    <select id="skill-level" >
      <option disabled selected>Select Sports of Interest</option>
      <option>Soccer</option>
      <option>Basketball</option>
      <option>Badminton</option>
  <option>Cricket</option>
  <option>Golf</option>
  <option>Volleyball</option>
  <option>Football</option>
  <option>Skating</option>
    </select>
       
       
      <label for="skill-level">Skill Level:</label>
      <select id="skill-level">
        <option disabled selected>Select Skill Level</option>
        <option>Beginner</option>
        <option>Intermediate</option>
        <option>Advanced</option>
      </select>
      <label for="availability">Availability:</label>
      <input type="text" placeholder="Days and Times Available">
      <textarea placeholder="Additional Comments"></textarea>
      <div class="terms">
        <input type="checkbox" id="terms" required>
        <label for="terms">I agree to the <a href="termsndcon.html">terms and conditions</a></label>
      </div>
      <button type="submit">Sign Up</button>
    </form>
  </div>
</body>
</html>
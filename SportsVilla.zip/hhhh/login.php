<?php
include('database.php');

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $admin_table_name = 'individual';

  $admin_query = $conn->prepare("SELECT * FROM $admin_table_name WHERE username = ? LIMIT 1");
  $admin_query->bind_param("s", $username);
  $admin_query->execute();
  $admin_result = $admin_query->get_result();

  if ($admin_result->num_rows > 0) {
      $user = $admin_result->fetch_assoc();

      if ($password == $user['password']) {
        header('Location: page1.html');
        exit();
      } else {
          $error_message = 'Invalid password. Please try again.';
      }
  } else {
      $error_message = 'User does not exist. Please try again.';
  }
}


// Close the database connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styleheader.css">
</head>
<style>
  *{
      margin:0px;
      padding:0px;
  }
  
  .header1{
      font-size: 1.5vw;
      width:100%;
      display:flex;
      flex-direction: row-reverse;
      justify-content: space-around;
     margin:47px 63px;
     margin-top:69px;
     
  }
 
.container3{

display: flex;
align-items: center;
justify-content: center;


}   
body {
font-family: Arial, sans-serif;
}
.login-container {
width: 300px;
height: 439px;
margin: 0 auto;
margin-top:35px;
background-color: #fff;
padding: 20px;
border-radius: 5px;
box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
}
.login-container h2 {
text-align: center;
align-items: center;
}
.form-group {
margin-bottom: 20px;
}
.form-group label {
display: block;
margin-bottom: 5px;
}
.form-group input {
width: 97%;
padding: 8px;
border: 1px solid #ccc;
border-radius: 3px;
}
.remember-me {
display: flex;
align-items: center;
justify-content: space-around;
margin-bottom: 15px;
}
.remember-me label {
margin-right: -117px;
margin-top: 3px;
}
.forgot-password {
text-align: right;
font-size: 14px;
}
.submit-btn {
width: 100%;
background-color: blue;
color: #fff;
border: none;
padding: 10px;
border-radius: 3px;
cursor: pointer;
}
.submit-btn:hover {
background-color: #45a049;
}
.header1 a:hover{
  border-top: solid 2px orange ;
}



</style>
<body>
        <div class="container2">
            
          <header>
            <div class="logo">
                        <img src="LOGO.png" alt="Logo">
                    </div>
                    <nav>
                        <ul>
                        <li><a href="index1.html">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Sign Up</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
                <li><a href="events.html">Events</a></li>
                        </ul>
                    </nav>
            </header>
        </div>
        <div class="container3">
           
            <div class="login-container">
                <h2>User Login</h2>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                  <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                  </div>
                  <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                  </div>
                  <div class="form-group remember-me">
                    <label for="remember">Remember me</label>
                    <input type="checkbox" id="remember" name="remember">
                  </div>
                  <div class="form-group forgot-password">
                    <a href="#">Forgot password?</a>
                  </div>
                  <button type="submit" class="submit-btn">
                  Submit</button>
                </form>
                
            <?php
            // Display error message if any
            if ($error_message !== "") {
                echo '<p class="error">' . $error_message . '</p>';
            }
            ?>
              </div>

        </div>
        
        </div>
      
    
</body>
</html>
function Makecard() {
    let clutter = "";

    const departments = ["APPLIED PSYCHOLOGY",
    "C",	
    "COMPUTER SCIENCE",	
   " ECONOMICS	",
    "EDUCATION"	,
    "ENGLISH",
    "ENVIRONMENTAL STUDIES",	
    "FOOD TECHNOLOGY",
    "GEOGRAPHY",
    "HINDI",
    "HISTORY",
    "HUMAN DEVELOPMENT&FAMILY EMPOWERMENT",
    "MATHEMATICS",	
    "MUSIC",
    "PHILOSOPHY	",
    "PHYSICAL EDUCATION",	
    "POLITICAL SCIENCE",	
    "SANSKRIT",
    "SOCIOLOGY",
    "NSS",
    "NCC",
    "THIRKAN-CLASSICAL",
    "THIRKAN-WESTERN",
    "NAVRANG",
    "DURVA ECO-CLUB",
    "SANGEETIKA",
    "PLACEMENT CELL",
    "FCC",
    "CLEANLINESS COMMITTEE",
    "FIFE I SOCIETY"
    ]; // Add your department names here

    


    
    for (let i = 0; i < 30; i++) {
        const departmentName = departments[i];
       
        
        clutter += `<article id="profile1" class="section">
            <figure>
            <div class="border">
        
            </div>
            </figure>
            <div class="name">
    
            
                <div class="text">
                    <h5><a href="login.php">${departmentName}</a></h5>
                </div>
            </div>   
        </article>`;
    }

    document.querySelector(".section1").innerHTML = clutter;
}

Makecard();

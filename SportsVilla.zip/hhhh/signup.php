<?php
// Include database connection
include "database.php";

// Initialize variables for error and success messages
$error_message = "";
$success_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 // Retrieve form data
 $firstname = $_POST['firstname'];
 $lastname = $_POST['lastname'];
 $age = $_POST['age'];
 $gender = $_POST['gender'];
 $email = $_POST['email'];
 $contact = $_POST['contact'];
 $address = $_POST['address'];
 $city = $_POST['city'];
 $state = $_POST['state'];
 $username = $_POST['username'];
 $password = $_POST['password'];

// Validate form data (you can add more validation as needed)
 if (empty($firstname) || empty($lastname) || empty($age) || empty($gender) || empty($email) || empty($contact) || empty($address) || empty($city) || empty($state) || empty($username) || empty($password)) {
 $error_message = "All fields are required.";
 } else {
 // Insert data into database
 $sql = "INSERT INTO individual (fname, lname, age, gender, email, contact, address, city, state, username, password) VALUES ('$firstname', '$lastname', $age, '$gender', '$email', '$contact', '$address', '$city', '$state', '$username', '$password')";
 if ($conn->query($sql) === TRUE) {
 // Signup successful, redirect to page1.html
 header("Location: page1.html");
 exit();
 } else {
 // Signup failed, display error message
 $error_message = "Error: " . $conn->error;
 }
 }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Website Signup</title>
    <link rel="stylesheet" href="styleheader.css">
    <link rel="stylesheet" href="stylefooter.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #3b8fa6;
			
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 10px;
			color:#27296d;
			font-family:Georgia;
			font-size:40px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="number"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="tel"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        select {
            width: 100%;
        }
        input[type="checkbox"] {
            margin-bottom: 20px;
        }
        input[type="submit"] {
            width: 100%;
            background-color:#27296d;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #f5c7f7;
        }
        input[type="text1"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
                    <img src="LOGO.png" alt="Logo">
                </div>
                <nav>
                    <ul>
                    <li><a href="index1.html">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Sign Up</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
                <li><a href="events.html">Events</a></li>
                    </ul>
                </nav>
        </header>
    <div class="container">
        <h1>Sign Up</h1>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required>

            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="">Select</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="contact">Contact:</label>
            <input type="tel" id="contact" name="contact" pattern="[0-9]{10}" required>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>

            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>

            <label for="state">State:</label>
            <input type="text" id="state" name="state" required>
            <label for="username">Username</label>
        <input type="text1" id="username" name="username" required>

             <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>


            <input type="checkbox" id="terms" name="terms" required>
            <label for="terms">I agree to the <a href="termsndcon.html">terms and conditions</a>.</label>

            <input type="submit" value="Sign Up">
        </form>
    </div>
    <footer>
        <div class="footer-container">
            <div class="footer-left">
                <h3>About Us</h3>
                <p>For all the sports lovers in a local area to connect with each other based on their interests and location. We aim to facilitate the formation of sports team, and foster a sense of community among sports enthusiasts.</p>
            </div>
            <div class="footer-center">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="footer-right">
                <h3>Contact Us</h3>
                <p>Email: info@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </footer>
</body>
</html>

<?php
// Include the database connection file
include "database.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $teamName = $_POST['teamname'];
    $sport = $_POST['sports'];
    $numMembers = $_POST['members'];
    $playerDetails = $_POST['detail'];
    $vacancies = $_POST['vacancy'];
    $location = $_POST['location'];
    $achievements = $_POST['achievement'];

    // Insert data into the 'team' table
    $sql = "INSERT INTO team (teamname, sports, members, detail, vacancy, location, achievement)
            VALUES ('$teamName', '$sport', '$numMembers', '$playerDetails', '$vacancies', '$location', '$achievements')";

    if ($conn->query($sql) === TRUE) {
        // Data inserted successfully
        echo "<script>alert('Team information submitted successfully!');</script>";
    } else {
        // Error in SQL query
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Information Form</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="styleheader.css">
    <link rel="stylesheet" href="stylefooter.css">
</head>
<body>
    <header>
        <div class="logo">
                    <img src="LOGO.png" alt="Logo">
                </div>
                <nav>
                    <ul>
                    <li><a href="index1.html">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Sign Up</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
                <li><a href="events.html">Events</a></li>
                    </ul>
                </nav>
        </header>
<h2>Team Information Form</h2>
<div class="container">
    <form id="teamForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label for="teamName">Team Name:</label>
            <input type="text" id="teamName" name="teamname" required>
        </div>
    
        <div class="form-group">
            <label for="sport">Sport Played:</label>
            <input type="text" id="sport" name="sports" required>
        </div>
    
        <div class="form-group">
            <label for="numMembers">Number of Members:</label>
            <input type="number" id="numMembers" name="members" required>
        </div>
    
        <div class="form-group">
            <label for="playerDetails">Player Details:</label>
            <textarea id="playerDetails" name="detail" rows="4" required></textarea>
        </div>
    
        <div class="form-group">
            <label for="vacancies">Number of Vacancies:</label>
            <input type="number" id="vacancies" name="vacancy" required>
        </div>
    
        <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>
        </div>
    
        <div class="form-group">
            <label for="achievements">Achievements:</label>
            <textarea id="achievements" name="achievement" rows="4" required></textarea>
        </div>
    
        <button type="submit">Submit</button>
    </form>
</div>

<footer>
    <div class="footer-container">
        <div class="footer-left">
            <h3>About Us</h3>
            <p>For all the sports lovers in a local area to connect with each other based on their interests and location. We aim to facilitate the formation of sports team, and foster a sense of community among sports enthusiasts.</p>
        </div>
        <div class="footer-center">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
        <div class="footer-right">
            <h3>Contact Us</h3>
            <p>Email: info@example.com</p>
            <p>Phone: +1234567890</p>
        </div>
    </div>
</footer>
<script src="script.js"></script>

</body>
</html>
